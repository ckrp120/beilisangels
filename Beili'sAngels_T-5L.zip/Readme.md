DESCRIPTION
------------

LOLCode Interpreter is a program that allows you to launch an application to interpret the LOLCode Programming Language. It provides an in-depth view of LOLCode translation process and error detection. It also includes lexical, syntax, and semantic analysis as front end, and code generation and optimization as back-end. 

REQUIREMENTS
------------

This program requires the following:
1. Eclipse IDE 2020‑09
2. Java SE Development Kit 8
3. e(fx)clipse. 

INSTALLATION
------------

Follow each step to run the program:
1. Go to https://www.eclipse.org/downloads/ and download the latest version of eclipse according to your Operating System Specifications.
2. Extract the files and follow the installation process.
3. Go to https://www.oracle.com/ph/java/technologies/javase/javase-jdk8-downloads.html and install the jdk8 appropriate for your Operating System.
4. To Install into Eclipse SDK, open your eclipse and download the latest release available. e(fx)clipse is an extension for your Eclipse IDE and can be installed using the "Install New Software" wizard. In the drop down select the release repository and in the filter enter e(fx)clipse and then let follow the Install Wizard to the end and restart Eclipse.

If the following steps provided above does not work. You may request for an access on github source code file and contact us at:
kpcadacio@up.edu.ph
knlabador@up.edu.ph
jtogbinar@up.edu.ph